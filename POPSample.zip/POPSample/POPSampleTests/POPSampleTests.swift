//
//  POPSampleTests.swift
//  POPSampleTests
//
//  Created by padalingam agasthian on 7/5/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import XCTest
@testable import POPSample

//class Fake_FoodService: Gettable
//{
//    
//    var getWasCalled = false
//    
//    func get(completionHandler: Result<[Food]> -> Void)
//    {
//        getWasCalled = true
//        let foodOne = Food(name: "Pizza", price: "100")
//        let foodTwo = Food(name: "Biriyani", price: "100")
//        completionHandler(.Success([foodOne,foodTwo]))
//        //completionHandler(Result.Success(food))
//    }
//}

class Fake_FoodService: Gettable
{
    
    var getWasCalled = false
    
    func get(completionHandler: Result<[Food]> -> Void)
    {
        getWasCalled = true
        let foodOne = Food(name: "Pizza", price: "100")
        let foodTwo = Food(name: "Biriyani", price: "100")
        completionHandler(.Success([foodOne,foodTwo]))
    }
}

class POPSampleTests: XCTestCase
{
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    func testFetchFood()
    {
        let storyBoard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let fakeFoodService = Fake_FoodService()
        let viewController = storyBoard.instantiateViewControllerWithIdentifier("third") as! ThirdViewController
        UIApplication.sharedApplication().keyWindow!.rootViewController = viewController
        XCTAssertNotNil(viewController.view)
        viewController.getFood(fakeFoodService)
        XCTAssertTrue(fakeFoodService.getWasCalled)
        XCTAssertEqual(viewController.dataSource.count, 2)
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
}
