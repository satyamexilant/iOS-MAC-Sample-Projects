//
//  FourthViewController.swift
//  POPSample
//
//  Created by padalingam agasthian on 7/5/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{

    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 1
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
            let cell = tableView.dequeueReusableCellWithIdentifier(FourthTableViewCell.reuseIdentifier, forIndexPath: indexPath) as! FourthTableViewCell
            let viewModel = MinionModeViewModel()
            cell.configure(withPresenter: viewModel)
            return cell
    }
}
