//
//  ThirdViewController.swift
//  POPSample
//
//  Created by padalingam agasthian on 7/5/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    @IBOutlet weak var tableView: UITableView!
    
    var dataSource = [Food]()
    {
        didSet
        {
            tableView.reloadData()
        }
    }

    override func viewDidLoad()
    {
        super.viewDidLoad()
        getFood(FoodService())
        // Do any additional setup after loading the view.
    }
    func getFood<S: Gettable where S.T == [Food]>(service:S)
    {
        service.get()
            { [weak self] result in
            switch result {
            case .Success(let food):
                self?.dataSource = food
            case .Failure(let error):
                self?.showError(error)
            }
        }
    }
    
    func showError(error:ErrorType)
    {
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return dataSource.count;
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath)
        
        let food = dataSource[indexPath.row]
        cell.textLabel?.text = food.nameOfTheFood
        cell.detailTextLabel?.text = food.priceOfTheFood
        
        return cell
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
