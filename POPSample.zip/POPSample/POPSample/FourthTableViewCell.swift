//
//  FourthTableViewCell.swift
//  POPSample
//
//  Created by padalingam agasthian on 7/5/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

typealias SwitchWithTextViewPresentable = protocol<TextPresentable, SwitchPresentable>

class FourthTableViewCell: UITableViewCell
{
    @IBOutlet private weak var label: UILabel!
    @IBOutlet private weak var switchToggle: UISwitch!
    
    private var delegate: SwitchWithTextViewPresentable?
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configure(withPresenter presenter: SwitchWithTextViewPresentable)
    {
        delegate = presenter
        label.text = presenter.text
        switchToggle.on = presenter.switchOn
        switchToggle.onTintColor = presenter.switchColor
    }

    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
    
    @IBAction func onSwitchToggle(sender: UISwitch)
    {
        delegate?.onSwitchTogleOn(sender.on)
    }


}
