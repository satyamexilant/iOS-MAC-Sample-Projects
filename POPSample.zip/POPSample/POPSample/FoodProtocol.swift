//
//  FoodProtocol.swift
//  POPSample
//
//  Created by padalingam agasthian on 7/5/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import Foundation
import UIKit

protocol Shakeable { }

extension Shakeable where Self: UIView
{
    
    func shake()
    {
        let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 0.05
        animation.repeatCount = 5
        animation.autoreverses = true
        animation.fromValue = NSValue(CGPoint: CGPointMake(self.center.x - 4.0, self.center.y))
        animation.toValue = NSValue(CGPoint: CGPointMake(self.center.x + 4.0, self.center.y))
        layer.addAnimation(animation, forKey: "position")
    }
}

protocol Dimmable {}

extension Dimmable where Self: UIView
{
    func dim()
    {
        let animation = CABasicAnimation(keyPath: "opacity")
        animation.duration = 0.05
        animation.repeatCount = 5
        animation.autoreverses = true
        animation.fromValue = 1.0
        animation.toValue = 0.5
        layer.addAnimation(animation, forKey: "opacity")
    }
}

protocol ReusableView: class {}

extension ReusableView where Self: UIView
{
    static var reuseIdentifier: String
    {
        return String(self)
    }
}

extension UITableViewCell: ReusableView,NibLoadableView { }

protocol NibLoadableView: class { }

extension NibLoadableView where Self: UIView
{
    
    static var NibName: String {
        return String(self)
    }
}

class Food
{
    var nameOfTheFood : String?
    var priceOfTheFood : String?
    init(name:String,price:String)
    {
        nameOfTheFood = name
        priceOfTheFood = price
    }
}

enum Result<T>
{
    case Success(T)
    case Failure(ErrorType)
}

protocol Gettable
{
    associatedtype T
    
    func get(completionHandler: Result<T> -> Void)
}

struct FoodService: Gettable
{
   // typealias T = [Food]
    func get(completionHandler: Result<[Food]> -> Void)
    {
        let foodOne = Food(name: "Pizza", price: "100")
        let foodTwo = Food(name: "Biriyani", price: "100")
        completionHandler(.Success([foodOne,foodTwo]))
    }
  
}

// your label protocol
protocol TextPresentable
{
    var text: String { get }
    var textColor: UIColor { get }
    var font: UIFont { get }
}

// your switch protocol
protocol SwitchPresentable
{
    var switchOn: Bool { get }
    var switchColor: UIColor { get }
    func onSwitchTogleOn(on: Bool)
}

extension SwitchPresentable {
    var switchColor: UIColor { return .yellowColor() }
}

struct MinionModeViewModel: SwitchWithTextViewPresentable
{
    //    This would usually be instantiated with the model
    //    to be used to derive the information below
    //    but in this case, my app is pretty static
}

// MARK: TextPresentable Conformance
extension MinionModeViewModel
{
    var text: String { return "Minion Mode" }
    var textColor: UIColor { return .yellowColor() }
    var font: UIFont { return .systemFontOfSize(19.0) }
}

// MARK: SwitchPresentable Conformance
extension MinionModeViewModel
{
    var switchOn: Bool { return false }
    var switchColor: UIColor { return .yellowColor() }
    
    func onSwitchTogleOn(on: Bool)
    {
        if on {
            print("The Minions are here to stay!")
        } else {
            print("The Minions went out to play!")
        }
    }
}




