//
//  ViewController.swift
//  POPSample
//
//  Created by padalingam agasthian on 7/5/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

//extension UIView
//{
//    
//    func shake()
//    {
//        let animation = CABasicAnimation(keyPath: "position")
//        animation.duration = 0.05
//        animation.repeatCount = 5
//        animation.autoreverses = true
//        animation.fromValue = NSValue(CGPoint: CGPointMake(self.center.x - 4.0, self.center.y))
//        animation.toValue = NSValue(CGPoint: CGPointMake(self.center.x + 4.0, self.center.y))
//        layer.addAnimation(animation, forKey: "position")
//    }
//}

class ViewController: UIViewController
{

    @IBOutlet weak var foodImage: FoodImage!
    @IBOutlet weak var button: Button!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func action(sender: AnyObject)
    {
        self.foodImage.shake()
        self.foodImage.dim()
        self.button.shake()
    }


}

