//
//  MyCellView.swift
//  tableviewExample
//
//  Created by avnish kumar on 29/03/16.
//  Copyright © 2016 avnish kumar. All rights reserved.
//

import Cocoa

class MyCellView: NSTableCellView {

    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)

        // Drawing code here.
    }
    
    
    @IBAction func myButton(_ sender: AnyObject) {
        
        Swift.print("hello")
    }
    
    
    @IBOutlet weak var myTableViewCell: NSTextField!
}
