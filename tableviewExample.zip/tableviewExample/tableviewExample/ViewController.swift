//
//  ViewController.swift
//  tableviewExample
//
//  Created by avnish kumar on 29/03/16.
//  Copyright © 2016 avnish kumar. All rights reserved.
//

import Cocoa

class ViewController: NSViewController, NSTableViewDataSource, NSTableViewDelegate {

    @IBOutlet weak var tableView: NSTableView!
    let array = ["avnish", "manish", "nishant", "sonu"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self

        // Do any additional setup after loading the view.
    }

    
    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    
    func numberOfRows(in tableView: NSTableView) -> Int
    {
        return array.count
    }
    
    
    func tableView(_ tableView: NSTableView,
        viewFor tableColumn: NSTableColumn?,
        row: Int) -> NSView?
    {
        let view = tableView.make(withIdentifier: "1", owner: self) as! MyCellView
        view.myTableViewCell.stringValue = array[row]
        return view
        
    }
    
    
    
    


}

