//
//  ViewController.swift
//  NoteApp
//
//  Created by swathi m on 5/20/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var myWebView: UIWebView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
//        let url = NSURL (string: "https://www.google.co.in")
//        let requestObj = NSURLRequest(URL: url!)
//        myWebView.loadRequest(requestObj)
        // Do any additional setup after loading the view, typically from a nib.
//        
//        var firstViewController:UIViewController = UIViewController()
//        // The following statement is what you need
//        var customTabBarItem:UITabBarItem = UITabBarItem(title: nil, image: UIImage(named: "Screen Shot 2016-05-23 at 10.07.17 AM")?.imageWithRenderingMode(UIImageRenderingMode.AlwaysOriginal), selectedImage: UIImage(named: "Screen Shot 2016-05-23 at 10.07.17 AM"))
//        firstViewController.tabBarItem = customTabBarItem
//        [[UINavigationBar appearance] setBarTintColor:[UIColor yellowColor]];
        
    }
    
    //     func numberOfSectionsInTableView(tableView: UITableView) -> Int {
//        // #warning Incomplete implementation, return the number of sections
//        return 1
//    }
//
//     func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        // #warning Incomplete implementation, return the number of rows
//        return 1
//    }


//    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 2
//    }
//    
//    
//    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
//        let cellIdentifier = "cell"
//        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,
//                                                               forIndexPath: indexPath) as! ClipboardCell
//   
//    
//    return cell
//    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addNote(sender: AnyObject) {
        
        
    }

}

